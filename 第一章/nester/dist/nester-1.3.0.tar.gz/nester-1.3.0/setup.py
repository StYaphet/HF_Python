from distutils.core import setup

setup(
		name = 'nester',
		version = '1.3.0',
		py_modules = ['nester'],
		author = 'haoyipeng',
		author_email = '947670170@qq.com',
		url = 'http://www.shorewb.com',
		description = 'A simple printer of nested list',
	)